# Auto Visit (/visit)
# Chris Crypto Gaming & Financials
# Youtube Channel : http://bit.ly/CCGYTC
# E-mail : chriscryptogaming@gmail.com
# ETH Donations : 0xf410dCC5b41BF683390aCF0d6D2f0CCb198f3f86
# BTC Donations : 1C7SVC1mPBcXPYwq2jM765MKgQLm1S7DkY
# Doge Donations : DDn8sexiCcpi4MSCA1NPGz3G6vJLFRUKQj
# ZEC Donations : t1SgzYXhusasn7xaMzBhqE3Lfx4fBfrEFyF
# LTC Donations : ltc1qqwzdz03z6h5y5382lgvyhsuykzcrz580mj89u9
# BCH Donations : qqzjvgs0s2leev5gtam6cfm6fqch0kxw9q3narmjj4
# LTC Clickbot : http://bit.ly/35ME9Cq
# Doge Clickbot : http://bit.ly/35RO21J
# ZEC Clickbot : http://bit.ly/37WdN2L
# BTC Clickbot : http://bit.ly/2sAM1Zz
# BCH Clickbot : http://bit.ly/2R9GymM
# Support us on Brave! : http://bit.ly/CCGBrave

#Imports
import asyncio
import logging
import re
import time
import os
import sys
import requests
import random
from requests.auth import HTTPProxyAuth

logging.basicConfig(level=logging.ERROR)

from telethon import TelegramClient, events, errors
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import GetBotCallbackAnswerRequest
from datetime import datetime
from colorama import Fore, init as color_ama
color_ama(autoreset=True)

os.system('cls' if os.name=='nt' else 'clear')

# my.telegram.org values, get your own there
api_id = 1127509
api_hash = '7919be907884f1d388803b03f1994d78'

dogeclick_channel = 'Litecoin_click_bot'
def maini(url1):
	ip1 = ['196.240.57.107',
	'37.120.217.219',
	'192.154.198.15',
	'217.138.202.147',
	'195.158.248.160',
	'195.158.248.162',
	'94.46.13.166',
	'195.158.248.150',
	'195.158.248.19',
	'185.189.114.28',
	'217.138.192.99',
	'89.249.64.212',
	'37.120.217.219',
	'196.196.216.3',
	'196.196.217.51',
	'45.248.78.131',
	'89.187.189.186',
	'89.238.186.244',
	'217.138.199.27',
	'37.120.209.211',
	'31.13.191.136',
	'195.158.248.164',
	'94.46.13.166',
	'195.158.248.51',
	'195.158.248.211',
	'139.5.177.214',
	'217.138.202.147',
	'103.107.199.139',
	'212.102.38.149',
	'185.210.217.115',
	'195.154.41.9',
	'139.5.177.214',
	'196.196.217.51',
	'176.107.184.131',
	'176.107.184.151',
	'176.107.185.163',
	'176.107.185.109',
	'103.120.66.70',
	'195.158.249.11',
	'195.158.249.15',
	'195.158.249.9',
	'195.158.249.7',
	'195.158.249.13',
	'185.99.3.104',
	'84.17.55.82',
	'37.120.210.107',
	'195.158.249.15',
	'195.158.249.13',
	'195.158.249.11',
	'195.158.249.7',
	'195.158.249.9',
	'217.138.219.137',
	'37.120.203.211',
	'82.102.22.92',
	'217.138.207.171',
	'185.99.3.104',
	'213.128.80.59',
	'107.150.95.27',
	'139.5.177.214',
	'217.138.192.99',
	'213.128.80.59',
	'107.150.95.27',
	'217.138.213.203',
	'178.175.133.99',
	'196.196.216.19',
	'196.196.217.43',
	'31.13.191.136',
	'195.158.248.19',
	'195.158.248.158',
	'195.158.248.3',
	'195.158.248.211',
	'141.98.103.171']
	ip2 = random.choice(ip1)
	ip3 = str(ip2)
	ip4 = ip3.replace("'", '')
	up1 = ['qDJkqJX8QoU4a5Hmabi1KY4W:tPMniNYQfkp6yEL6DLkseoDM',
	'1AFSJRX88MxcYDtLrzaP7GsJ:wtM5zqKKMe5FkvuvWAME3eTc',
	'Kr1H5riUmE2MUbZt6PSScpdo:EGhiWwDmNqrbaDcEV6SWJjxC',
	'qm7dby25r1PTMK7cUzmdjPEk:8v68SSCDH2xezURGETiBdkvb',
	'UeHrrFnHdJQTryfuoBZqdxg7:bRXuaL5cjAsZfjeRHsh8a7Pr',
	'GFbhuQryxZF5cLk3MJVZNwEq:28zNUKD8wigSEQZmm4BJ1eek',
	's1riPKcbAfXLMypqonzAt83H:fvYfCNuneWKi2CwtZnyY8dFe',
	'WCBaKaDWNHet8M7X5drh1o15:aHa1A6H9dxFbb9xxHmpST46d',
	'TeDG8YNFm8PJJNBxTGGucD14:CtfRXbJCPRq557agvciTofrM',
	'5TqA4SDtpTPRiHjYzAZA52GM:2hQ18kf2cqiTX9JmfQu2XNfa']
	up2 = random.choice(up1)
	u1 = re.findall(r'[\w]+:', up2)
	p1 = re.findall(r':+[\w]+[\w]', up2)
	u2 = str(u1)
	u3 = u2.replace(':', '')
	u3 = u3.replace('[', '')
	u3 = u3.replace("'", '')
	u3 = u3.replace(']', '')
	p2 = str(p1)
	p3 = p2.replace(':', '')
	p3 = p3.replace('[', '')
	p3 = p3.replace("'", '')
	p3 = p3.replace(']', '')
	proxies = {"http":"http://" + ip4}
	auth = HTTPProxyAuth(u3, p3)
	session = requests.Session()
	if True:
		try:
			amir = session.get(url1, proxies=proxies, auth=auth)
			mir = amir.text
			if 'from this proxy server until you have authenticated yourself' not in mir:
				return mir
			elif 'from this proxy server until you have authenticated yourself' in mir:
				maini(url1)
		except (requests.exceptions.TooManyRedirects, requests.exceptions.ConnectionError, requests.exceptions.ProxyError):
			maini(url1)



# Date & Time Header
def print_msg_time(message):
	print('[' + Fore.YELLOW + f'{datetime.now().strftime("%H:%M:%S")}' + Fore.RESET + f'] {message}')

async def main():

	print(Fore.RED       + '       )  (    (    (              (        )  (               ) ')
	print(Fore.RED       + ' (    ( /(  )\ ) )\ ) )\ )      (    )\ )  ( /(  )\ )  *   )  ( /( ')
	print(Fore.RED       + '  )\   )\())(()/((()/((()/(      )\  (()/(  )\())(()/(` )  /(  )\()) ')
	print(Fore.YELLOW    + ' (((_) ((_)\  /(_))/(_))/(_))   (((_)  /(_))((_)\  /(_))( )(_))((_)\ ')
	print(Fore.YELLOW    + ') )\___  _((_)(_)) (_)) (_))     )\___ (_)) __ ((_)(_)) (_(_())  ((_) ')
	print(Fore.YELLOW    + ')((/ __|| || || _ \|_ _|/ __|   ((/ __|| _ \ \ \ / /| _ \|_   _| / _ \ ')
	print(Fore.BLUE      + ' )| (__ | __ ||   / | | \__ \    | (__ |   /  \ V / |  _/  | |  | (_) |')
	print(Fore.BLUE      + '  \____||_||_||_|_\|___||___/     \___||_|_\   |_|  |_|    |_|   \___/ \n' + Fore.RESET)
	print(Fore.BLUE   + '                      BY :CHRIS CRYPTO GAMING \n' + Fore.RESET)
	print(Fore.BLUE   + '                  YT Channel : http://bit.ly/CCGYTC  \n' + Fore.RESET)



	# Check if phone number is not specified
	if len(sys.argv) < 2:
		print('Usage: python start.py phone_number')
		print('-> Input number in international format (example: +639162995600)\n')
		e = input('Press any key to exit...')
		exit(1)

	phone_number = sys.argv[1]

	if not os.path.exists("session"):
		os.mkdir("session")

	# Connect to client
	client = TelegramClient('session/' + phone_number, api_id, api_hash)
	await client.start(phone_number)
	me = await client.get_me()

	print(Fore.GREEN + f'Current account: {me.first_name}({me.username})\n' + Fore.RESET)
	print_msg_time('Sending /join command')

	# Start command /visit
	await client.send_message(dogeclick_channel, '/join')
	@client.on(events.NewMessage(chats=dogeclick_channel, incoming=True))
	async def join_start(event):
		try:
			url1 = event.original_update.message.reply_markup.rows[0].buttons[0].url
			message = event.raw_text
			if 'Press the "Go to group"' in message:
				print_msg_time(f'skip group!...')

				# Clicks skip button
				await client(GetBotCallbackAnswerRequest(
					peer=dogeclick_channel,
					msg_id=event.message.id,
					data=event.message.reply_markup.rows[1].buttons[1].data
				))
			# Join channel
			elif 'Press the "Go to channel"' in message:
				mir = maini(url1)
				e = re.findall(r"""<meta name="twitter:app:url:googleplay" content="https://t.me+\b/\w+""", mir)
				f = str(e)
				d = f.replace("""['<meta name="twitter:app:url:googleplay" content=""", '')
				d = d.replace('"', '')
				d = d.replace("']", '')
				print_msg_time(f'Joining @{d}...')

				# Verifying Join
				await client(JoinChannelRequest(d))
				print_msg_time(f'Verifying...')

				# Clicks joined button
				await client(GetBotCallbackAnswerRequest(
					peer=dogeclick_channel,
					msg_id=event.message.id,
					data=event.message.reply_markup.rows[0].buttons[1].data
				))
		except (ValueError, errors.rpcerrorlist.UsernameInvalidError):
			await client(GetBotCallbackAnswerRequest(
				peer=dogeclick_channel,
				msg_id=event.message.id,
				data=event.message.reply_markup.rows[0].buttons[1].data
			))
		except errors.rpcerrorlist.FloodWaitError:
			print_msg_time(f'you must wait')
			exit()
		except AttributeError:
			pass

	# Print waiting hours
	@client.on(events.NewMessage(chats=dogeclick_channel, incoming=True))
	async def wait_hours(event):
		message = event.raw_text
		if 'You must stay' in message:
			waiting_hours = re.search(r'at least (.*?) to earn', message).group(1)
			print_msg_time(Fore.GREEN + f'Success! Please wait {waiting_hours} to earn reward\n' + Fore.RESET)
		elif 'If this message persists' in message:
			await client(GetBotCallbackAnswerRequest(
				peer=dogeclick_channel,
				msg_id=event.message.id,
				data=event.message.reply_markup.rows[1].buttons[1].data
			))
		elif 'We cannot find' in message:
			await client(GetBotCallbackAnswerRequest(
				peer=dogeclick_channel,
				msg_id=event.message.id,
				data=event.message.reply_markup.rows[1].buttons[1].data
			))

	# No more ads
	@client.on(events.NewMessage(chats=dogeclick_channel, incoming=True))
	async def no_ads(event):
		message = event.raw_text
		if 'no new ads available' in message:
			print_msg_time(Fore.RED + 'Sorry, there are no new ads available\n' + Fore.RESET)


	# No more ads - balance inquiry - close
	@client.on(events.NewMessage(chats=dogeclick_channel, incoming=True))
	async def no_ads(event):
		message = event.raw_text
		if 'Sorry,' in message:
			await client.send_message(dogeclick_channel, '/balance')
		if 'Available balance:' in message:
			print_msg_time(Fore.GREEN + event.raw_text + '\n' + Fore.RESET)



			exit(1)
	await client.run_until_disconnected()

asyncio.get_event_loop().run_until_complete(main())
